<?php
/**
 * Title: 404
 * Slug: tree-secrets-blog-theme/404
 * Inserter: no
 */
?>
<!-- wp:template-part {"slug":"header","tagName":"header","area":"header"} /-->

<!-- wp:group {"tagName":"main","style":{"spacing":{"margin":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50"},"blockGap":"var:preset|spacing|30"}},"layout":{"type":"constrained","contentSize":"90%"}} -->
<main class="wp-block-group" style="margin-top:var(--wp--preset--spacing--50);margin-bottom:var(--wp--preset--spacing--50)"><!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns"><!-- wp:column {"layout":{"type":"default"}} -->
<div class="wp-block-column"><!-- wp:heading {"textAlign":"center","level":1,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base-3"}}},"layout":{"selfStretch":"fit","flexSize":null}},"textColor":"base-3"} -->
<h1 class="wp-block-heading has-text-align-center has-base-3-color has-text-color has-link-color" id="page-not-found"><?php /* Translators: 1. is the start of a 'strong' HTML element, 2. is the end of a 'strong' HTML element, 3. is the start of a 'mark' HTML element, 4. is the end of a 'mark' HTML element */ 
echo sprintf( esc_html__( '%1$sOops! %2$s%3$sSomething went wrong!%4$s', 'tree-secrets-blog-theme' ), '<strong>', '</strong>', '<mark style="background-color:rgba(0, 0, 0, 0)" class="has-inline-color has-contrast-2-color">', '</mark>' ); ?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p><?php /* Translators: 1. is the start of a 'a' HTML element, 2. is the end of a 'a' HTML element */ 
echo sprintf( esc_html__( 'The page you are looking for doesn’t exist. Try typing something else or go straight to%1$s the main site%2$s', 'tree-secrets-blog-theme' ), '<a href="' . esc_url( 'http://treesecrets-dev.local/' ) . '" data-type="page" data-id="110">', '</a>' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:search {"label":"Search","showLabel":false,"buttonText":"Search","fontSize":"medium"} /--></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:image {"sizeSlug":"full","linkDestination":"none","align":"center"} -->
<figure class="wp-block-image aligncenter size-full"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/404Error.png" alt=""/></figure>
<!-- /wp:image --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></main>
<!-- /wp:group -->

<!-- wp:template-part {"slug":"footer","tagName":"footer","area":"footer"} /-->