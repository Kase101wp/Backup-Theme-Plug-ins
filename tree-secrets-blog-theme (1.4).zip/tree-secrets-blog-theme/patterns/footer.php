<?php
/**
 * Title: footer
 * Slug: tree-secrets-blog-theme/footer
 * Inserter: no
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:columns {"align":"wide","style":{"spacing":{"blockGap":{"top":"0","left":"0"},"margin":{"bottom":"var:preset|spacing|30"},"padding":{"bottom":"0"}}}} -->
<div class="wp-block-columns alignwide" style="margin-bottom:var(--wp--preset--spacing--30);padding-bottom:0"><!-- wp:column {"width":"30%"} -->
<div class="wp-block-column" style="flex-basis:30%"><!-- wp:group {"style":{"dimensions":{"minHeight":""},"layout":{"selfStretch":"fit","flexSize":null}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"center"}} -->
<div class="wp-block-group"><!-- wp:site-logo {"width":212,"shouldSyncIcon":false,"style":{"layout":{"selfStretch":"fit","flexSize":null}}} /--></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"15%"} -->
<div class="wp-block-column" style="flex-basis:15%"></div>
<!-- /wp:column -->

<!-- wp:column {"width":"25%","style":{"border":{"top":{"color":"var:preset|color|base-3","width":"1px"},"bottom":{"color":"var:preset|color|base-3","width":"1px"}},"spacing":{"padding":{"right":"var:preset|spacing|10","left":"var:preset|spacing|10","top":"0","bottom":"var:preset|spacing|20"}}}} -->
<div class="wp-block-column" style="border-top-color:var(--wp--preset--color--base-3);border-top-width:1px;border-bottom-color:var(--wp--preset--color--base-3);border-bottom-width:1px;padding-top:0;padding-right:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--10);flex-basis:25%"><!-- wp:paragraph {"style":{"spacing":{"padding":{"top":"var:preset|spacing|10","bottom":"var:preset|spacing|10"}}}} -->
<p style="padding-top:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--10)"><?php esc_html_e('AFFILIATE DISCLOSURE', 'tree-secrets-blog-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"spacing":{"padding":{"right":"0","left":"0"}}},"fontSize":"small"} -->
<p class="has-small-font-size" style="padding-right:0;padding-left:0"><?php /* Translators: 1. is the start of a 'strong' HTML element, 2. is the end of a 'strong' HTML element */ 
echo sprintf( esc_html__( 'The owner of this website, tree-secrets.com, is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn advertising fees by advertising and linking tree-secrets.com Review to Amazon properties including, but not limited to, amazon.com %1$sThis occurs at no extra cost to you, and we appreciate your support. %2$s', 'tree-secrets-blog-theme' ), '<strong>', '</strong>' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"25%","style":{"spacing":{"blockGap":"0px","padding":{"right":"var:preset|spacing|10","left":"var:preset|spacing|10"}},"border":{"top":{"color":"var:preset|color|base-3","width":"1px"},"bottom":{"color":"var:preset|color|base-3","width":"1px"}}}} -->
<div class="wp-block-column" style="border-top-color:var(--wp--preset--color--base-3);border-top-width:1px;border-bottom-color:var(--wp--preset--color--base-3);border-bottom-width:1px;padding-right:var(--wp--preset--spacing--10);padding-left:var(--wp--preset--spacing--10);flex-basis:25%"><!-- wp:paragraph {"style":{"spacing":{"padding":{"top":"var:preset|spacing|10","bottom":"var:preset|spacing|10"}}}} -->
<p style="padding-top:var(--wp--preset--spacing--10);padding-bottom:var(--wp--preset--spacing--10)"><?php esc_html_e('CONTACT', 'tree-secrets-blog-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"0","right":"0"}}}} -->
<p style="padding-top:var(--wp--preset--spacing--20);padding-right:0;padding-bottom:var(--wp--preset--spacing--20);padding-left:0"><?php esc_html_e('PO Box 275, Scappoose, Oregon. 97056. United States', 'tree-secrets-blog-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}}} -->
<p style="padding-top:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20)"><?php /* Translators: 1. is the start of a 'a' HTML element, 2. is the end of a 'a' HTML element */ 
echo sprintf( esc_html__( '%1$shello@tree-secrets.com%2$s', 'tree-secrets-blog-theme' ), '<a href="' . esc_url( 'mailto:hello@tree-secrets.com' ) . '">', '</a>' ); ?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->

<!-- wp:separator {"align":"wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}}} -->
<hr class="wp-block-separator alignwide has-alpha-channel-opacity" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:var(--wp--preset--spacing--20)"/>
<!-- /wp:separator -->

<!-- wp:navigation {"ref":2176,"align":"wide","style":{"typography":{"fontStyle":"normal","fontWeight":"300","textTransform":"uppercase"}},"fontSize":"small","layout":{"type":"flex","justifyContent":"center","flexWrap":"wrap"}} /-->

<!-- wp:separator {"align":"wide","style":{"spacing":{"margin":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"}}}} -->
<hr class="wp-block-separator alignwide has-alpha-channel-opacity" style="margin-top:var(--wp--preset--spacing--20);margin-bottom:var(--wp--preset--spacing--20)"/>
<!-- /wp:separator --></div>
<!-- /wp:group -->