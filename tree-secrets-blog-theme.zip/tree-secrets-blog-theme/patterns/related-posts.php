<?php
/**
 * Title: related-posts
 * Slug: tree-secrets-blog-theme/related-posts
 * Inserter: no
 */
?>
<!-- wp:heading {"style":{"elements":{"link":{"color":{"text":"var:preset|color|contrast-4"}}}},"textColor":"contrast-4","fontSize":"large","fontFamily":"system-sans-serif"} -->
<h2 class="wp-block-heading has-contrast-4-color has-text-color has-link-color has-system-sans-serif-font-family has-large-font-size"><?php /* Translators: 1. is the start of a 'strong' HTML element, 2. is the end of a 'strong' HTML element */ 
echo sprintf( esc_html__( '%1$sRelated Posts%2$s', 'tree-secrets-blog-theme' ), '<strong>', '</strong>' ); ?></h2>
<!-- /wp:heading -->

<!-- wp:query {"queryId":43,"query":{"perPage":"4","pages":"1","offset":"0","postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"metadata":{"categories":["posts"],"patternName":"twentytwentyfour/posts-images-only-3-col","name":"Posts with featured images only, 3 columns"},"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-query alignwide"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|10","bottom":"var:preset|spacing|10","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--10);padding-right:0;padding-bottom:var(--wp--preset--spacing--10);padding-left:0"><!-- wp:post-template {"align":"full","style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"grid","columnCount":"2"}} -->
<!-- wp:cover {"useFeaturedImage":true,"dimRatio":50,"overlayColor":"contrast-4","isUserOverlayColor":true,"style":{"dimensions":{"aspectRatio":"16/9"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover"><span aria-hidden="true" class="wp-block-cover__background has-contrast-4-background-color has-background-dim"></span><div class="wp-block-cover__inner-container"><!-- wp:post-title {"textAlign":"center","isLink":true,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base-4"}}}},"textColor":"base-4","fontSize":"medium","fontFamily":"system-sans-serif"} /--></div></div>
<!-- /wp:cover -->
<!-- /wp:post-template --></div>
<!-- /wp:group --></div>
<!-- /wp:query -->