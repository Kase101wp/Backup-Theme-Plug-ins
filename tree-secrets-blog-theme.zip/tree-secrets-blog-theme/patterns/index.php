<?php
/**
 * Title: index
 * Slug: tree-secrets-blog-theme/index
 * Inserter: no
 */
?>
<!-- wp:template-part {"slug":"header","tagName":"header","area":"header"} /-->

<!-- wp:group {"tagName":"main","align":"full","layout":{"type":"constrained"}} -->
<main class="wp-block-group alignfull"><!-- wp:group {"align":"full","backgroundColor":"base-3","layout":{"type":"default"}} -->
<div class="wp-block-group alignfull has-base-3-background-color has-background"><!-- wp:heading {"textAlign":"center","level":1,"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|30"}},"elements":{"link":{"color":{"text":"var:preset|color|base-4"}}}},"textColor":"base-4"} -->
<h1 class="wp-block-heading alignwide has-text-align-center has-base-4-color has-text-color has-link-color" style="padding-top:var(--wp--preset--spacing--30)"><?php esc_html_e('All Articles', 'tree-secrets-blog-theme');?></h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"var:preset|color|base-4"}}}},"textColor":"base-4"} -->
<p class="has-text-align-center has-base-4-color has-text-color has-link-color"><?php esc_html_e('This is a complete list of all the articles on this site (Latest Post First)', 'tree-secrets-blog-theme');?></p>
<!-- /wp:paragraph -->

<!-- wp:spacer {"height":"38px"} -->
<div style="height:38px" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer --></div>
<!-- /wp:group -->

<!-- wp:query {"queryId":4,"query":{"perPage":"1","pages":0,"offset":"0","postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"enhancedPagination":true,"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-query alignwide"><!-- wp:query-no-results -->
<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center"><?php esc_html_e('No articles were found ', 'tree-secrets-blog-theme');?></p>
<!-- /wp:paragraph -->
<!-- /wp:query-no-results -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|10","bottom":"var:preset|spacing|10","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--10);padding-right:0;padding-bottom:var(--wp--preset--spacing--10);padding-left:0"><!-- wp:post-template {"align":"full","style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"grid","columnCount":1}} -->
<!-- wp:cover {"useFeaturedImage":true,"dimRatio":50,"customOverlayColor":"#566878","isUserOverlayColor":true,"layout":{"type":"constrained"}} -->
<div class="wp-block-cover"><span aria-hidden="true" class="wp-block-cover__background has-background-dim" style="background-color:#566878"></span><div class="wp-block-cover__inner-container"><!-- wp:post-title {"textAlign":"center","isLink":true,"style":{"layout":{"flexSize":"min(2.5rem, 3vw)","selfStretch":"fixed"},"elements":{"link":{"color":{"text":"var:preset|color|base-4"}}}},"textColor":"base-4","fontSize":"x-large"} /-->

<!-- wp:post-date {"textAlign":"center","isLink":true,"style":{"elements":{"link":{"color":{"text":"var:preset|color|base-4"}}}},"textColor":"base-4","fontSize":"medium"} /--></div></div>
<!-- /wp:cover -->
<!-- /wp:post-template --></div>
<!-- /wp:group --></div>
<!-- /wp:query -->

<!-- wp:query {"queryId":4,"query":{"perPage":"12","pages":0,"offset":"1","postType":"post","order":"desc","orderBy":"date","author":"","search":"","exclude":[],"sticky":"","inherit":false},"enhancedPagination":true,"align":"wide","layout":{"type":"default"}} -->
<div class="wp-block-query alignwide"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"0","right":"0"},"margin":{"top":"0","bottom":"0"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--20);padding-right:0;padding-bottom:var(--wp--preset--spacing--20);padding-left:0"><!-- wp:post-template {"align":"full","style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"grid","columnCount":3}} -->
<!-- wp:cover {"useFeaturedImage":true,"dimRatio":50,"customOverlayColor":"#826671","isUserOverlayColor":true,"style":{"dimensions":{"aspectRatio":"4/3"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover"><span aria-hidden="true" class="wp-block-cover__background has-background-dim" style="background-color:#826671"></span><div class="wp-block-cover__inner-container"><!-- wp:post-title {"isLink":true,"style":{"layout":{"flexSize":"min(2.5rem, 3vw)","selfStretch":"fixed"},"elements":{"link":{"color":{"text":"var:preset|color|base-4"}}}},"textColor":"base-4","fontSize":"medium"} /-->

<!-- wp:read-more {"style":{"elements":{"link":{"color":{"text":"var:preset|color|base-4"}}},"spacing":{"padding":{"right":"var:preset|spacing|10","left":"var:preset|spacing|10","top":"0","bottom":"0"}},"border":{"width":"1px","color":"#ffffff","radius":"24px"}},"textColor":"base-4"} /--></div></div>
<!-- /wp:cover -->
<!-- /wp:post-template -->

<!-- wp:spacer {"height":"var:preset|spacing|40","style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<div style="margin-top:0;margin-bottom:0;height:var(--wp--preset--spacing--40)" aria-hidden="true" class="wp-block-spacer"></div>
<!-- /wp:spacer -->

<!-- wp:query-pagination {"paginationArrow":"arrow","layout":{"type":"flex","justifyContent":"space-between"}} -->
<!-- wp:query-pagination-previous /-->

<!-- wp:query-pagination-next /-->
<!-- /wp:query-pagination --></div>
<!-- /wp:group --></div>
<!-- /wp:query --></main>
<!-- /wp:group -->

<!-- wp:template-part {"slug":"footer","tagName":"footer","area":"footer"} /-->