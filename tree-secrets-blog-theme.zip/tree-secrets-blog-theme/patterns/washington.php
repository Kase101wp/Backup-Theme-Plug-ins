<?php
/**
 * Title: Washington
 * Slug: tree-secrets-blog-theme/washington
 * Categories: Adverts
 */
?>
<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-base-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:media-text {"align":"wide","mediaId":2203,"mediaLink":"http://treesecrets-dev.local/washington-ornament-landscape/","linkDestination":"custom","mediaType":"image","mediaWidth":51,"style":{"spacing":{"padding":{"right":"var:preset|spacing|40","left":"var:preset|spacing|40"}}}} -->
<div class="wp-block-media-text alignwide is-stacked-on-mobile" style="padding-right:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40);grid-template-columns:51% auto"><figure class="wp-block-media-text__media"><a href="https://treesecretsstore.etsy.com"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/Washington-Ornament-Landscape.png" alt="<?php esc_attr_e('Washington Ornament', 'tree-secrets-blog-theme');?>" class="wp-image-2203 size-full"/></a></figure><div class="wp-block-media-text__content"><!-- wp:buttons {"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)"><!-- wp:button {"width":75} -->
<div class="wp-block-button has-custom-width wp-block-button__width-75"><a class="wp-block-button__link wp-element-button"><?php esc_html_e('Shop Now', 'tree-secrets-blog-theme');?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:media-text --></div>
<!-- /wp:group -->