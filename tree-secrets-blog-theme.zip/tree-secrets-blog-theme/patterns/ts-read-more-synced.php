<?php
/**
 * Title: TS - Read More Synced
 * Slug: tree-secrets-blog-theme/ts-read-more-synced
 * Categories: Featured
 */
?>
<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:group {"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|10","bottom":"var:preset|spacing|10","left":"var:preset|spacing|30","right":"var:preset|spacing|30"},"margin":{"top":"var:preset|spacing|20","bottom":"var:preset|spacing|20"},"blockGap":"0"},"border":{"top":{"color":"var:preset|color|base-3"},"bottom":{"color":"var:preset|color|base-3"}}},"backgroundColor":"base-2","layout":{"type":"default"}} -->
<div class="wp-block-group alignwide has-base-2-background-color has-background" style="border-top-color:var(--wp--preset--color--base-3);border-bottom-color:var(--wp--preset--color--base-3);margin-top:var(--wp--preset--spacing--20);margin-bottom:var(--wp--preset--spacing--20);padding-top:var(--wp--preset--spacing--10);padding-right:var(--wp--preset--spacing--30);padding-bottom:var(--wp--preset--spacing--10);padding-left:var(--wp--preset--spacing--30)"><!-- wp:group {"backgroundColor":"base-2","layout":{"type":"constrained"}} -->
<div class="wp-block-group has-base-2-background-color has-background"><!-- wp:paragraph {"align":"center","style":{"elements":{"link":{"color":{"text":"#277217"}}},"color":{"text":"#277217","background":"#f2fbef"},"typography":{"fontSize":"37px","fontStyle":"normal","fontWeight":"700","lineHeight":"0.7"}}} -->
<p class="has-text-align-center has-text-color has-background has-link-color" style="color:#277217;background-color:#f2fbef;font-size:37px;font-style:normal;font-weight:700;line-height:0.7"><?php /* Translators: 1. is the start of a 'em' HTML element, 2. is the start of a 'strong' HTML element, 3. is the end of a 'strong' HTML element, 4. is the end of a 'em' HTML element */ 
echo sprintf( esc_html__( '%1$s%2$sRead More%3$s%4$s', 'tree-secrets-blog-theme' ), '<em>', '<strong>', '</strong>', '</em>' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:list {"className":"is-style-readmore"} -->
<ul class="wp-block-list is-style-readmore"><!-- wp:list-item -->
<li><?php esc_html_e('item 1', 'tree-secrets-blog-theme');?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e('item 2', 'tree-secrets-blog-theme');?></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><?php esc_html_e('Item 3', 'tree-secrets-blog-theme');?></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->