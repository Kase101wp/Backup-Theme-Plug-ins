<?php
/**
* Plugin Name: TreeSecrets List Block Styles
* Description: Adds TreeSecret Styles to the List Block.
* Version: 1.0
* Author: Phil
* Text Domain: ts-block-style
*
*@package create-block
*
*/

function wp_dev_register_block_style() {

    wp_enqueue_block_style(
        'core/list',
        array(
            'handle' => 'ts-block-style',
            'src' => plugins_url( 'ts-list-style.css', __FILE__),
        )
    );

    register_block_style(
        'core/list',
        array(
            'name' => 'greentree', // .is.style.greentree
            'label' => 'Green Tree',
        )
    );

    register_block_style(
        'core/list',
        array(
            'name' => 'readmore', // .is.style.readmore
            'label' => 'Read More',
        )
    );
}
add_action( 'init', 'wp_dev_register_block_style');

?>